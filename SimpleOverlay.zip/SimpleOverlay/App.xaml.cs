using System.Windows;

namespace SimpleOverlay;

public partial class App : Application
{
}